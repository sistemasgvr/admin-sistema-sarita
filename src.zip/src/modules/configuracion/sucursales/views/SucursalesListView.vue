<template>
  <div>
    <PageBreadcrumb page-title="Sucursales" />

    <AppTable
      :columns="columns"
      :rows="rows"
      row-key="id"
      :loading="isLoading"
    >
      <template #toolbar>
        <AppListToolbar
          v-model:search="buscar"
          search-placeholder="Código, nombre o dirección..."
        >
          <template #actions>
            <button
              v-if="canCreate"
              type="button"
              class="inline-flex shrink-0 items-center justify-center gap-2 rounded-lg bg-brand-500 px-4 py-2.5 text-sm font-medium text-white shadow-theme-xs transition hover:bg-brand-600"
              @click="openCreateModal"
            >
              <AppIcon :name="ICONS.plus" :size="18" />
              Nuevo
            </button>
          </template>
        </AppListToolbar>
      </template>

      <template #actions="{ row }">
        <button
          v-if="canEdit"
          type="button"
          title="Editar"
          class="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm font-medium text-brand-500 hover:bg-brand-50 dark:hover:bg-brand-500/10"
          @click="openEditModal(row)"
        >
          <AppIcon :name="ICONS.pencil" :size="16" />
          <!-- Editar -->
        </button>

        <button
          v-if="canDelete"
          type="button"
          title="Eliminar"
          class="inline-flex items-center gap-1 rounded-lg px-2 py-1.5 text-sm font-medium text-error-500 hover:bg-error-500/10"
          @click="openDeleteModal(row)"
        >
          <AppIcon :name="ICONS.trash" :size="16" />
          <!-- Eliminar -->
        </button>
      </template>

      <template #footer>
        <AppPagination
          v-model:pagina="pagina"
          v-model:limite="limite"
          :meta="sucursalesQuery.data.value?.meta"
          :disabled="isLoading"
        />
      </template>
    </AppTable>

    <SucursalFormModal
      v-model="formModalOpen"
      :mode="formMode"
      :sucursal="selectedSucursal"
      @saved="onSucursalSaved"
    />

    <AppModal
      v-model="deleteModalOpen"
      title="Eliminar sucursal"
      subtitle="Esta acción desactivará la sucursal en el sistema."
      size="sm"
    >
      <p class="text-sm text-gray-600 dark:text-gray-400">
        ¿Confirmas que deseas eliminar
        <span class="font-medium text-gray-800 dark:text-white/90">
          {{ sucursalToDelete?.nombre }}
        </span>
        ?
      </p>

      <template #footer>
        <button
          type="button"
          class="flex w-full justify-center rounded-lg border border-gray-300 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:bg-gray-800 dark:text-gray-300 dark:hover:bg-white/[0.03] sm:w-auto"
          :disabled="deleteMutation.isPending.value"
          @click="deleteModalOpen = false"
        >
          Cancelar
        </button>
        <button
          type="button"
          class="flex w-full justify-center rounded-lg bg-error-500 px-4 py-2.5 text-sm font-medium text-white hover:bg-error-600 disabled:cursor-not-allowed disabled:opacity-70 sm:w-auto"
          :disabled="deleteMutation.isPending.value"
          @click="confirmDelete"
        >
          {{ deleteMutation.isPending.value ? 'Eliminando...' : 'Eliminar' }}
        </button>
      </template>
    </AppModal>
  </div>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import PageBreadcrumb from '@/modules/admin/components/PageBreadcrumb.vue'
import SucursalFormModal from '@/modules/configuracion/sucursales/components/SucursalFormModal.vue'
import { useDeleteSucursalMutation } from '@/modules/configuracion/sucursales/composables/useSucursalMutations'
import { useSucursalesQuery } from '@/modules/configuracion/sucursales/composables/useSucursalesQuery'
import type {
  Sucursal,
  SucursalFormMode,
  SucursalListFilters,
} from '@/modules/configuracion/sucursales/interfaces/sucursal.interface'
import { useAuthStore } from '@/modules/auth/stores/auth.store'
import { AppListToolbar, AppModal, AppPagination, AppTable } from '@/shared/components'
import AppIcon from '@/shared/components/AppIcon.vue'
import { ICONS } from '@/shared/constants/icons'
import { PermisoBanderas } from '@/shared/constants/permissions'
import type { TableColumn } from '@/shared/interfaces/table.interface'

const authStore = useAuthStore()

const buscar = ref('')
const pagina = ref(1)
const limite = ref(10)

const filters = ref<SucursalListFilters>({
  buscar: '',
  pagina: 1,
  limite: 10,
})

const sucursalesQuery = useSucursalesQuery(filters)
const deleteMutation = useDeleteSucursalMutation()

const formModalOpen = ref(false)
const formMode = ref<SucursalFormMode>('create')
const selectedSucursal = ref<Sucursal | null>(null)

const deleteModalOpen = ref(false)
const sucursalToDelete = ref<Sucursal | null>(null)

const canCreate = computed(() => authStore.hasPermission(PermisoBanderas.SUCURSALES_CREAR))
const canEdit = computed(() => authStore.hasPermission(PermisoBanderas.SUCURSALES_EDITAR))
const canDelete = computed(() => authStore.hasPermission(PermisoBanderas.SUCURSALES_ELIMINAR))

const isLoading = computed(() => sucursalesQuery.isFetching.value)
const rows = computed(() => sucursalesQuery.data.value?.data ?? [])

const columns = computed<TableColumn<Sucursal>[]>(() => [
  { key: 'codigo', label: 'Código' },
  { key: 'nombre', label: 'Nombre' },
  { key: 'direccion', label: 'Dirección' },
  { key: 'telefono', label: 'Teléfono' },
])

let buscarTimeout: ReturnType<typeof setTimeout> | undefined

const syncFilters = () => {
  filters.value = {
    buscar: buscar.value.trim(),
    pagina: pagina.value,
    limite: limite.value,
  }
}

watch(buscar, () => {
  clearTimeout(buscarTimeout)
  buscarTimeout = setTimeout(() => {
    pagina.value = 1
    syncFilters()
  }, 350)
})

watch([pagina, limite], () => {
  syncFilters()
})

const openCreateModal = () => {
  formMode.value = 'create'
  selectedSucursal.value = null
  formModalOpen.value = true
}

const openEditModal = (sucursal: Sucursal) => {
  formMode.value = 'edit'
  selectedSucursal.value = sucursal
  formModalOpen.value = true
}

const openDeleteModal = (sucursal: Sucursal) => {
  sucursalToDelete.value = sucursal
  deleteModalOpen.value = true
}

const confirmDelete = async () => {
  if (!sucursalToDelete.value) return

  try {
    await deleteMutation.mutateAsync(sucursalToDelete.value.id)
    deleteModalOpen.value = false
    sucursalToDelete.value = null
  } catch {
    // toast en mutation
  }
}

const onSucursalSaved = () => {
  selectedSucursal.value = null
}
</script>
